package pageobject;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class TaskPage extends MenuPage {

	public TaskPage(WebDriver driver) {
		super(driver);
	}

//  *addnewteam
	@FindBy(css = "div:nth-child(2) > h1 > div.sidebar-add-button.tooltipped-w.tooltipped-delay.style-module__tooltip___3RTDW.tooltipped > span")
	private WebElement pressaddteam;
	@FindBy(css = "#form-input3")
	private WebElement addnameteam;
	@FindBy(css = "div:nth-child(4) > div > div.group-members__member-add > div > input")
	private WebElement addnameemail;
	@FindBy(css = "div.group-members__member-add > div > div > div:nth-child(1) > div > div > div.column.p\\:flex-grow")
	private WebElement clickemail;
	@FindBy(css = " div.row.row--bg-light.p\\:items-center.spacing-4--inner > button")
	private WebElement clickcreate;
	@FindBy(css = "div.row.p\\:items-center.spacing-2--inner-top.font-tiny.text--color-new-error")
	private WebElement getmessage;

//  *addtaskteam
	@FindBy(css = " div.p\\:cursor-interactive.grid__row.grid__row--borderless")
	private WebElement addtaskteam;
	@FindBy(css = ".style-module__text___1DYSo")
	private List<WebElement> namelist;

//	*filltask
	@FindBy(css = "[name='search_name']")
	private WebElement addnametask;
	@FindBy(css = ".style-module__input-popup-value___2Ofa8 > div")
	private WebElement clickstatus;
	@FindBy(css = "div.style-module__input-popup-options___2i7iL > div:nth-child(2)")
	private WebElement addstatus;
	@FindBy(css = "#dynamic-input-view2331")
	private WebElement adddate;
	@FindBy(css = "[data-placeholder='Type to add notes...']")
	private WebElement addnotes;
	@FindBy(css = "span.style-module__close___6nzLH.style-module__icon___2JruS.icon-svg.icon-svg--12")
	private WebElement closetask;

//	*swapstatusteam
	@FindBy(css = "[data-name='hello']")
	private List<WebElement> movetotask;
	@FindBy(css = "[data-hook='status']")
	private List<WebElement> clickstatuss;
	@FindBy(css = "[data-value='in_progress']")
	private WebElement clickinprogress;

// 	*deletetaskfromteam
	@FindBy(css = ".menu-item.delete")
	private WebElement clickdelete;

//	*deleteteamfromlist
	@FindBy(css = ".style-module__text___1DYSo")
	private List<WebElement> foundnameteam;
	@FindBy(css = ".style-module__button___3N2wB")
	private List<WebElement> clickdropdown;
	@FindBy(css = ".menu-item.delete")
	private WebElement deleteteam;
	@FindBy(css = "#success-confirm")
	private WebElement clickyes;

//	*addnewplan
	@FindBy(css = "[data-hook='add-project']")
	private WebElement clickaddplan;
	@FindBy(css = "[name='project_name']")
	private WebElement fillnameplan;
	@FindBy(css = "div.row.row--bg-light.p\\:items-center.spacing-4--inner > button.button-v2.button-v2--medium.button-v2--primary.button-v2--fixed-width")
	private WebElement clickadd;

//	*addtaskplanboard
	@FindBy(css = ".style-module__projects___3dweF >div")
	private List<WebElement> foundnameplan;
	@FindBy(css = "[data-hook='board-view']")
	private List<WebElement> clickboard;
	@FindBy(css = "div.board-module__main___2Qn5Z > div:nth-child(1) > div.p\\:flex-auto.p\\:min-w-0.p\\:min-h-0.board-module__viewport-container___o1fC6 > button")
	private WebElement clickaddtask;

//	*deleteplanfromlist
	@FindBy(css = ".style-module__button___2o4Ox")
	private List<WebElement> movetomenu;
	@FindBy(css = "[data-hook='remove-button']")
	private WebElement clickdeleteplan;
	@FindBy(css = "#success-confirm")
	private WebElement deleteplan;

//	*adduser
	@FindBy(css = "[data-hook='manage-users']")
	private WebElement clickadduser;
	@FindBy(css = "[data-hook='search-text']")
	private WebElement fillnameuser;
	@FindBy(css = "div:nth-child(2) > div > div.column.hover.text--underlined.text--color-new-link > div")
	private WebElement clickcreateuser;
	@FindBy(css = "[data-hook='button-cancel']")
	private WebElement clickclose;

//	*deleteuser
	@FindBy(css = ".grid__user__name")
	private List<WebElement> clicknameuser;
	@FindBy(css = "[aria-label='Delete user']")
	private WebElement clickbuttondeleteuser;
	@FindBy(css = "#success-confirm")
	private WebElement clickdeleteuser;
	@FindBy(css = "[data-hook='settings-done']")
	private WebElement clicksave;

//	signout
	@FindBy(css = "[data-hook='current-account-name']")
	private WebElement clickdropdownemail;
	@FindBy(css = ".account-logout")
	private WebElement clicksignout;

//	search
	@FindBy(css = "span.p\\:font-light.p\\:leading-relaxed.p\\:text-md")
	private WebElement clicksearch;
	@FindBy(css = "[name='quick-search']")
	private WebElement fillsearch;
	@FindBy(css = "[data-hook='name']")
	private List<WebElement> clicknamesearch;

//	addarchive
	@FindBy(css = "[data-hook='archive-button']")
	private WebElement clickaddarchive;

//	searcharchive
	@FindBy(css = "[data-hook='show-archive']")
	private WebElement clickshowarchive;
	@FindBy(css = "[data-hook='input-search']")
	private WebElement fillsearcharchive;
	@FindBy(css = ".empty.empty--projects-list")
	private WebElement getsearchmessage;
	@FindBy(css = "[data-hook=\"button-x\"]")
	private WebElement clicksearchdone;

//	unarchive
	@FindBy(css = "[data-action='Unarchive']")
	private WebElement clickunarchive;

	public void pressAddTeam() {
		click(pressaddteam);
		sleep(1000);
	}

	public void addNameTeam(String text) {
		fillText(addnameteam, text);
	}

	public void addNameEmail() {
		click(addnameemail);
		sleep(500);
		click(clickemail);
		sleep(500);
		click(clickcreate);
	}

	public String geterror() {
		return getText(getmessage);
	}

	public void pressNameOfList(String text) {
		for (WebElement el1 : namelist) {
			if (getText(el1).equalsIgnoreCase(text)) {
				click(el1);
				sleep(1000);
			}
		}
	}

	public void addTaskTeam() {
		click(addtaskteam);
		sleep(1000);

	}

	public void fillTask(String name, String text) {
		fillText(addnametask, name);
		fillText(addnotes, text);

	}

	public void closeTask() {
		click(closetask);

	}

	public void swapStatusTeam(String text) {
		for (int i = 0; i < movetotask.size(); i++) {
			if (getText(movetotask.get(i)).equalsIgnoreCase(text)) {
				moveTo(movetotask.get(i));
				sleep(500);
				click(clickstatuss.get(i));
				click(clickinprogress);
			}
		}
	}

	public void deleteTaskTeam(String text) {
		for (int i = 0; i < movetotask.size(); i++) {
			if (getText(movetotask.get(i)).equalsIgnoreCase(text)) {
				moveTo(movetotask.get(i));
				sleep(500);
				click(clickdelete);
			}
		}
	}

	public void deleteTeamFromList(String name) {
		for (int i = 0; i < foundnameteam.size(); i++) {
			if (getText(foundnameteam.get(i)).equalsIgnoreCase(name)) {
				click(foundnameteam.get(i));
				actions.moveToElement(foundnameteam.get(i)).build().perform();
				click(clickdropdown.get(i));
				click(deleteteam);
				click(clickyes);
			}
		}
	}

	public void addNewPlan(String text) {
		click(clickaddplan);
		sleep(500);
		fillText(fillnameplan, text);
		sleep(1000);
		click(clickadd);
	}

	public void addNewTaskPlan(String name) {
		for (int i = 0; i < foundnameplan.size(); i++) {
			if (getText(foundnameplan.get(i)).equalsIgnoreCase(name)) {
				click(foundnameplan.get(i));
				sleep(1000);
				click(clickboard.get(i));
				sleep(500);
				click(clickaddtask);

			}
		}
	}

	public void deletePlanFromList(String name) {
		for (int i = 0; i < foundnameteam.size(); i++) {
			if (getText(foundnameplan.get(i)).equalsIgnoreCase(name)) {
				click(foundnameplan.get(i));
				actions.moveToElement(movetomenu.get(i)).build().perform();
				click(movetomenu.get(i));
				click(clickdeleteplan);
				sleep(500);
				click(deleteplan);

			}
		}
	}

	public void addUser(String text) {
		click(clickadduser);
		sleep(500);
		fillText(fillnameuser, text);
		sleep(500);
		click(clickcreateuser);
		sleep(500);
		click(clickclose);
		sleep(2000);
	}

	public void deleteUser(String name) {
		for (int i = 0; i < clicknameuser.size(); i++) {
			if (getText(clicknameuser.get(i)).equalsIgnoreCase(name)) {
				click(clicknameuser.get(i));
				sleep(500);
				click(clickbuttondeleteuser);
				sleep(500);
				click(clickdeleteuser);
				sleep(500);
				click(clicksave);
			}
		}
	}

	public void signOut() {
		click(clickdropdownemail);
		sleep(500);
		click(clicksignout);

	}

	public void search(String text, String name) {
		click(clicksearch);
		fillText(fillsearch, name);
		sleep(500);
		for (int i = 0; i < clicknamesearch.size(); i++) {
			if (getText(clicknamesearch.get(i)).equalsIgnoreCase(text)) {
				sleep(500);
				click(clicknamesearch.get(i));

			}
		}
	}

	public void addArchive(String name) {
		for (int i = 0; i < foundnameplan.size(); i++) {
			if (getText(foundnameplan.get(i)).equalsIgnoreCase(name)) {
				click(foundnameplan.get(i));
				actions.moveToElement(movetomenu.get(i)).build().perform();
				click(movetomenu.get(i));
				sleep(1000);
				click(clickaddarchive);

			}
		}
	}

	public void searchArchive(String text) {
		click(clickshowarchive);
		fillText(fillsearcharchive, text);
		sleep(1000);

	}

	public String getSearchError() {
		return getText(getsearchmessage);
	}

	public void unrchive() {
		sleep(1000);
		click(clickunarchive);
	}

}
