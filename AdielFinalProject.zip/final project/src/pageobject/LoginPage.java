package pageobject;

import java.awt.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginPage extends MenuPage {

	public LoginPage(WebDriver driver) {
		super(driver);
	}

	@FindBy(css = "#form-input1")
	private WebElement email;

	@FindBy(css = "#form-input2")
	private WebElement password;

	@FindBy(css = " div.auth__body > div > form > button")
	private WebElement presslogin;

	@FindBy(css = ".auth-form__forgot")
	private WebElement pressforgetpassword;

	@FindBy(css = ".auth__error.auth__error--visible")
	private WebElement geterrormessage;

	public void fillLogin(String email1, String password1) {
		fillText(email, email1);
		fillText(password, password1);
		click(presslogin);
		sleep(2000);
	}

	public void pressForgetPassword() {
		click(pressforgetpassword);
	}

	public String getMessage() {
		return getText(geterrormessage);
	}

}
