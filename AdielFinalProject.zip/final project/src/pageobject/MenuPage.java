package pageobject;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MenuPage extends BasePage{

	public MenuPage(WebDriver driver) {
		super(driver);
	}
	@FindBy (css = "div.hero > div.nav > div.nav-btns > a:nth-child(1)")
	private WebElement pressProduct;
	
	@FindBy (css = " div.hero > div.nav > div.nav-btns > a:nth-child(2)")
	private WebElement pressPricing;
	
	@FindBy (css = "div.nav-btns > a:nth-child(3)")
	private WebElement pressSupport;
	
	@FindBy (css = " a.button.login.w-button")
	private WebElement pressLogin;
	
	@FindBy (css = " a.button.signup.w-button")
	private WebElement pressSignUp;

	public void pressProduct() {
		click(pressProduct);
		sleep(500);
	}
	public void pressPricing() {
		click(pressPricing);
		sleep(500);
	}
	public void pressSupport() {
		click(pressSupport);
		sleep(500);
	}
	public void pressLogin() {
		click(pressLogin);
		sleep(500);
	}
	public void pressSignUp() {
		click(pressSignUp);
		sleep(500);
	}

}
