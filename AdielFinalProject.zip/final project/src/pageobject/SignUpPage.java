package pageobject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class SignUpPage extends MenuPage {

	public SignUpPage(WebDriver driver) {
		super(driver);
	}

	@FindBy(css = "#form-input1")
	private WebElement email;

	@FindBy(css = "#form-input2")
	private WebElement password;

	@FindBy(css = " div.auth__content__tos-checkbox > div")
	private WebElement presscheckbox;

	@FindBy(css = " div.auth__body > div > form > button")
	private WebElement presssignup;

	@FindBy(css = "form > div:nth-child(5) > div > div.row.p\\:items-center.spacing-2--inner-top.font-tiny.text--color-new-error")
	private WebElement geterror;

	public void fillSignUp(String email1, String password1) {
		fillText(email, email1);
		fillText(password, password1);
		click(presscheckbox);
		click(presssignup);
	}

	public String getErrorPassword() {
		return getText(geterror);
	}

}
