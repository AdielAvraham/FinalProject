package pageobject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ForgetPasswordPage extends MenuPage{

	public ForgetPasswordPage(WebDriver driver) {
		super(driver);
	}
	@FindBy(css = "#form-input3")
	private WebElement email;
	
	@FindBy(css = "div.auth__body > div > form > button")
	private WebElement presssend;
	
	@FindBy (css = " div > form > button")
	private WebElement presslogin;
	
	public void fillForgetPassword(String email1) {
		fillText(email, email1);
		click(presssend);
	}

	
	
}
