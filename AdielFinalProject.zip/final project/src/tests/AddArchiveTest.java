package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import pageobject.LoginPage;
import pageobject.MenuPage;
import pageobject.TaskPage;

public class AddArchiveTest extends BaseTest {

	@Test
	public void tc01_addNewPlan() throws InterruptedException {
		TaskPage tp = new TaskPage(driver);
		tp.addNewPlan("adiel");
		Thread.sleep(1000);
	}

	@Test
	public void tc02_addArchive() {
		TaskPage tp = new TaskPage(driver);
		tp.addArchive("adiel");
	}
}
