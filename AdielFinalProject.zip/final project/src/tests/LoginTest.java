package tests;

import org.openqa.selenium.support.ui.Sleeper;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pageobject.LoginPage;
import pageobject.MenuPage;
import pageobject.SignUpPage;

public class LoginTest extends BaseTest {
	@Test
	public void tc01_pressSignUp() {
		MenuPage mp = new MenuPage(driver);
		mp.pressLogin();
	}

	@Test(dataProvider = "getdata")
	public void tc02_loginTest(String email, String password) {
		LoginPage lp = new LoginPage(driver);
		lp.fillLogin(email, password);
		String message = "Unable to log in. Please check your email and password.";
		String actual = lp.getMessage();
		Assert.assertEquals(actual, message);
	}

	@DataProvider
	public Object[][] getdata() {
		Object[][] data = { { "adiel41@gmail.com", "adiel1994" }, { "adiel1541@gmail.com", "adi" },

		};
		return data;
	}

	@Test
	public void tc03_loginTestSecceed() {
		LoginPage lp = new LoginPage(driver);
		lp.fillLogin("adiel1541@gmail.com", "adiel1994");
	}

}
