package tests;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pageobject.LoginPage;
import pageobject.MenuPage;
import pageobject.TaskPage;

public class AddNewTeamTest extends BaseTest {

	@Test
	public void tc01_pressAddTeam() {
		TaskPage tp = new TaskPage(driver);
		tp.pressAddTeam();
	}

	@Test
	public void tc02_addNameTeam() {
		TaskPage tp = new TaskPage(driver);
		tp.addNameTeam("adiel");

	}

	@Test
	public void tc03_addNameEmail() {
		TaskPage tp = new TaskPage(driver);
		tp.addNameEmail();

	}

}
