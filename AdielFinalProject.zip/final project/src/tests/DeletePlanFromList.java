package tests;

import java.lang.annotation.Target;

import org.testng.annotations.Test;

import pageobject.LoginPage;
import pageobject.MenuPage;
import pageobject.TaskPage;

public class DeletePlanFromList extends BaseTest {

	@Test
	public void tc01_addNewPlan() {
		TaskPage tp = new TaskPage(driver);
		tp.addNewPlan("adiel avr");

	}

	@Test
	private void tc02_deletePlan() {
		TaskPage tp = new TaskPage(driver);
		tp.deletePlanFromList("adiel avr");
	}
}
