package tests;

import org.testng.annotations.Test;

import pageobject.LoginPage;
import pageobject.MenuPage;
import pageobject.TaskPage;

public class AddTaskPlanTest extends BaseTest {

	@Test
	public void tc01_addNewPlan() {
		TaskPage tp = new TaskPage(driver);
		tp.addNewPlan("adiell");
	}

	@Test
	public void tc02_addTaskPlan() {
		TaskPage tp = new TaskPage(driver);
		tp.addNewTaskPlan("adiell");
	}

	@Test
	public void tc03_fillTaskTeam() {
		TaskPage tp = new TaskPage(driver);
		tp.fillTask("hello", "my first");
	}

	@Test
	public void tc04_closeTask() {
		TaskPage tp = new TaskPage(driver);
		tp.closeTask();

	}

}
