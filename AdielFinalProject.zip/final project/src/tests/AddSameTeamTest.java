package tests;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pageobject.LoginPage;
import pageobject.MenuPage;
import pageobject.TaskPage;

public class AddSameTeamTest extends BaseTest {
	@Test
	public void tc01_pressSignUp() {
		MenuPage mp = new MenuPage(driver);
		mp.pressLogin();
	}

	@Test
	public void tc02_loginTestSecceed() throws InterruptedException {
		LoginPage lp = new LoginPage(driver);
		lp.fillLogin("adiel1541@gmail.com", "adiel1994");
		Thread.sleep(6000);
	}

	@Test
	public void tc03_pressAddTeam() {
		TaskPage tp = new TaskPage(driver);
		tp.pressAddTeam();
	}

	@Test(dataProvider = "getdata")
	public void tc04_addNameTeam(String name) throws InterruptedException {
		TaskPage tp = new TaskPage(driver);
		tp.addNameTeam(name);
		String message = "*Team with this name already exists";
		String actual = tp.geterror();
		Assert.assertEquals(actual, message);
	}

	@Test
	public void tc05_addNameemail() {
		TaskPage tp = new TaskPage(driver);
		tp.addNameEmail();

	}

	@DataProvider
	public Object[][] getdata() {
		Object[][] data = { { "adiel" }, { "adi" },

		};
		return data;
	}

}
