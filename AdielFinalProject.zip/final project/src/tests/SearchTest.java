package tests;

import static org.testng.Assert.assertEquals;

import org.testng.Assert;
import org.testng.annotations.Test;

import pageobject.LoginPage;
import pageobject.MenuPage;
import pageobject.TaskPage;

public class SearchTest extends BaseTest {

	@Test
	public void tc01_pressAddTeam() {
		TaskPage tp = new TaskPage(driver);
		tp.pressAddTeam();
	}

	@Test
	public void tc02_addNameTeam() {
		TaskPage tp = new TaskPage(driver);
		tp.addNameTeam("adiel avraham");

	}

	@Test
	public void tc03_addNameEmail() throws InterruptedException {
		TaskPage tp = new TaskPage(driver);
		tp.addNameEmail();
		Thread.sleep(3000);

	}

	@Test
	public void tc04_search() {
		TaskPage tp = new TaskPage(driver);
		tp.search("adiel avraham", "adiel avraham");

	}
}
