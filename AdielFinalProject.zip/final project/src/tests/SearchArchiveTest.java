package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import pageobject.LoginPage;
import pageobject.MenuPage;
import pageobject.TaskPage;

public class SearchArchiveTest extends BaseTest {

	@Test
	public void tc01_addNewPlan() throws InterruptedException {
		TaskPage tp = new TaskPage(driver);
		tp.addNewPlan("adi");
		Thread.sleep(1000);
	}

	@Test
	public void tc02_addArchive() throws InterruptedException {
		TaskPage tp = new TaskPage(driver);
		tp.addArchive("adi");
		Thread.sleep(1000);
	}

	@Test
	public void tc03_searchArchive() {
		TaskPage tp = new TaskPage(driver);
		tp.searchArchive("adiel");
		String message = "No projects found matching \"adiel\"";
		String actual = tp.getSearchError();
		Assert.assertEquals(actual, message);
	}
}
