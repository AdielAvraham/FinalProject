package tests;

import org.testng.annotations.Test;

import pageobject.LoginPage;
import pageobject.MenuPage;
import pageobject.TaskPage;

public class AddUserTest extends BaseTest {

	@Test
	public void tc01_addUser() {
		TaskPage tp = new TaskPage(driver);
		tp.addUser("adiel");
	}
}
