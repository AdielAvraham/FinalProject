package tests;

import org.testng.annotations.Test;

import pageobject.ForgetPasswordPage;
import pageobject.LoginPage;
import pageobject.MenuPage;

public class ForgetPasswordTest extends BaseTest {
	@Test
	public void tc01_pressSignUp() {
		MenuPage mp = new MenuPage(driver);
		mp.pressLogin();
	}

	@Test
	public void tc02_pressForgetPassword() {
		LoginPage lp = new LoginPage(driver);
		lp.pressForgetPassword();
	}

	@Test
	public void tc03_fillForgetPassword() {
		ForgetPasswordPage fpp = new ForgetPasswordPage(driver);
		fpp.fillForgetPassword("adiel1541@gmail.com");
	}
}
