package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import pageobject.LoginPage;
import pageobject.MenuPage;
import pageobject.TaskPage;

public class UnarchiveTest extends BaseTest {

	@Test
	public void tc01_addNewPlan() throws InterruptedException {
		TaskPage tp = new TaskPage(driver);
		tp.addNewPlan("adiel avraham");
		Thread.sleep(1000);
	}

	@Test
	public void tc02_addArchive() throws InterruptedException {
		TaskPage tp = new TaskPage(driver);
		tp.addArchive("adiel avraham");
		Thread.sleep(2000);
	}

	@Test
	public void tc03_searchArchive() {
		TaskPage tp = new TaskPage(driver);
		tp.searchArchive("adiel avraham");

	}

	@Test
	public void tc04_unArchive() {
		TaskPage tp = new TaskPage(driver);
		tp.unrchive();

	}
}
