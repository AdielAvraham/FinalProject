package tests;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pageobject.MenuPage;
import pageobject.SignUpPage;

public class SignUpTest extends BaseTest {
	@Test
	public void tc01_pressSignUp() {
		MenuPage mp = new MenuPage(driver);
		mp.pressSignUp();
	}

	@Test(dataProvider = "getdata")
	public void tc02_signUpTest(String email, String password) {
		SignUpPage sup = new SignUpPage(driver);
		sup.fillSignUp(email, password);
		String message = "*Minimum 8 characters";
		String actual = sup.getErrorPassword();
		Assert.assertEquals(actual, message);
	}

	@DataProvider
	public Object[][] getdata() {
		Object[][] data = { { "adiel541@gmail", "adi994" }, { "adiel1541@gmail.com", "adi" },

		};
		return data;
	}
}
