package tests;

import org.testng.annotations.Test;

import pageobject.LoginPage;
import pageobject.MenuPage;
import pageobject.TaskPage;

public class SignOutTest extends BaseTest {

	@Test
	public void tc01_signOut() {
		TaskPage tp = new TaskPage(driver);
		tp.signOut();
	}
}
