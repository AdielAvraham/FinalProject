package tests;

import org.testng.annotations.Test;

import pageobject.LoginPage;
import pageobject.MenuPage;
import pageobject.TaskPage;

public class AddNewPlanTest extends BaseTest {

	@Test
	public void tc01_addNewPlan() {
		TaskPage tp = new TaskPage(driver);
		tp.addNewPlan("adiel avraham");
	}
}
